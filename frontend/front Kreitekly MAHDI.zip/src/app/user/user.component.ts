import {Component, OnInit} from '@angular/core';
import {SongInterface} from "../interfaces/SongInterface";
import {UserService} from "./services/user.service";

@Component({
  selector: 'app-user',
  templateUrl: './user.component.html',
  styleUrls: ['./user.component.css']
})
export class UserComponent implements OnInit{

  newestMusicsTitle = 'novedades';
  newestSong !: SongInterface[];
  filterCategory :string | undefined=undefined;

  constructor(private userService:UserService) {

  }

  ngOnInit(): void {
    this.userService.getFilter().subscribe(value => {

      this.filterCategory = value
      console.log(value)
      this.loadNewestSongs();
    })


  }






  private loadNewestSongs() {

    console.log(this.filterCategory + 'from user components')

    this.userService.newestSongs(this.filterCategory).subscribe({
      next:data =>this.newestSong = data,
      error:err => console.log(err),
      complete:()=>console.log('loaded newest songs')
    })
  }
}
