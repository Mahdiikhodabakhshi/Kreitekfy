export interface UserSongInterface {
  id:number
  userId:string
  songId:number
  personalPlays:number
  personalValorations:number|null
}
